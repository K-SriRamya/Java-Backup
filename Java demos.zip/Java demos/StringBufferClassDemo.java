package demo;

public class StringBufferClassDemo {
	public static void main(String args[]) {
		StringBuffer stb=new StringBuffer();
		System.out.println(stb.capacity());
		StringBuffer sb=new StringBuffer("welcome ");
		System.out.println("length:"+sb.length());
		System.out.println("capacity:"+sb.capacity());
		sb.append("to ");
		System.out.println(sb);
		sb.append("java ");
		System.out.println(sb);
		sb.append("Language ");
		System.out.println(sb);
		sb.insert(16, "programming ");
		System.out.println(sb);
	
	String s=new String(sb);
	System.out.println(s);
	}
}


