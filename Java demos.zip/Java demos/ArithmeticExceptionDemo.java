package demo;

public class ArithmeticExceptionDemo {
	public static void main(String args[]) {
		try {
			int i=10/0;
			System.out.println("after try block");
		}catch(ArithmeticException ae) {
		System.out.println("Exception raised");
	}
	System.out.println("reamaining block of code");
}
}
