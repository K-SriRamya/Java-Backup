package service;

import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import bean.Employee;
import dao.DaoHash;
//import dao.DaoLayer;


public class ServiceLayer {
	//DaoLayer dobj=new DaoLayer();
	DaoHash dobj=new DaoHash();
	public void addEmp(Employee e) {
		dobj.addEmp(e);
		
		
	}
public void retriveEmpId() {
		
	}
	public List<Entry<Integer, String>> sortname() {
		return dobj.sortname();
		
	}
	public Set<Entry<Integer, String>> sortid() {
		return dobj.sortid();
		
	}
	public void retriveEmpName() {
		
	}
	
}
