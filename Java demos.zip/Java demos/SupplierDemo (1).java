package demo;

import java.util.function.Supplier;

public class SupplierDemo {
	public static void main(String args[]) {
		Supplier<Double> randomValue= () -> Math.random();
		double d=(randomValue.get())*10;
		System.out.println((int)d);
	}

}
