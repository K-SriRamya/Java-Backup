package com.cg.bean;

public interface InvoiceService {
	
	int calculateInvoice(Invoice bean);

}
