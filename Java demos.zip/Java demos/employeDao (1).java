package com.employeeDao;
import com.employeeBean.*;
import java.util.*;
public class employeDao {
	Methods array[] = new Methods[10];
	public void datastore(Methods m1) {
		array[0] = m1;
		System.out.println("added successfully."+(m1));
		
	}
	public void dataretrieve(Methods m2) {
		if(array[0]==null) {
			System.out.println("employee not found");
		}
		else {
			if(array[0].getEmpid()==m2.getEmpid()) {
				System.out.println("employeeid"+" " +array[0].getEmpid()+" "+"empname:"+" "+array[0].getEmployeename()+" "+"empsalary"+" "+array[0].getEmployeesalary()+" "+"insuranceamt"+array[0].getInsuranceamt());
			}
			else {
				System.out.println("error");
			}
		}
		
	}
	public void datadelete(Methods m3) {
		if(array[0]==null) {
			System.out.println("employyee not found");
		}
		else {
			if(array[0].getEmpid()==m3.getEmpid()) {
				array[0]=null;
				System.out.println("deletion successfull");
			}
			else {
				System.out.println("error");
			}
		}
		
	}

}
