package demo;

import java.util.function.*;

interface Mess{
	String dispMess();
}
interface Messageable{
	Message getMessage(String msg);
}
class Message{
	Message(){
		System.out.println("message const");
	}
	Message(String msg){
		System.out.println(msg);
	}
	public int calcLength(String l) {
		return l.length();
	}
}
public class MethodReferenceDemo {
	static String display() {
		return "hello";
	}
	public static void main(String args[]) {
		System.out.println(String.valueOf(65));
		
		//lambdaExpression
		Function<Integer,String> func1=x->String.valueOf(x);
		System.out.println("Function 	"+func1.apply(10));
		
		//using a methodreference
		Function<Integer,String> func2=String::valueOf;
		System.out.println(func2.apply(10));
		
		//uses a method ref
		BiFunction<Integer,Integer,Integer> func4=Integer::sum;
		System.out.println(func4.apply(2,3));
		
		//constructor ref with fun interface
		Messageable m=Message::new;
		m.getMessage("hi");
		
		//method ref with obj
		Message mobj=new Message();
		Function<String,Integer> c=mobj::calcLength;
		System.out.println(c.apply("hello"));
		
		//uses a lambda exp
		BiFunction<Integer,Integer,Integer> func3=(x,y)-> Integer.sum(x, y);
		System.out.println(func3.apply(2,3));
		
		Mess m2=MethodReferenceDemo::display;
		m2.dispMess();
		
		
		
	}

}
